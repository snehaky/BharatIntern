package com.example.quizeapp11;

public class QuestionAnswer {
    public static String question[] ={
            "Who is the prime minister of India?",
            "Which one is not the programming language?",
            "Which is the capital city of Karnataka?",
            "Which is the capital city of India?"
    };

    public static String choices[][] = {
            {"Narendra modi","Murmu","obama","Nehru"},
            {"Java","Kotlin","Notepad","Python"},
            {"Bellary","Bengaluru","Dharwad","Kochi"},
            {"Delhi","Karnataka","Kerala","Nepal"}
    };

    public static String correctAnswers[] = {
            "Narendra modi",
            "Notepad",
            "Bengaluru",
            "Delhi"
    };
}
